const mongoose = require('mongoose');
const Schema = mongoose.Schema;
//monggose

// Define collection and schema
let Student = new Schema({
  student_name: {
    type: String
  },
  student_incident: {
    type: String
  },
  section: {
    type: String
  },
  subjects: {
    type: Array
  },
  gravedad: {
    type: String
  },
  dob: {
    type: Date
  }
}, {
  collection: 'students'
})

module.exports = mongoose.model('Student', Student)